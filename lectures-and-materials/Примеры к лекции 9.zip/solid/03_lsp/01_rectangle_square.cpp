// 5.3 LSP — нарушение: Square нельзя подставить вместо Rectangle
#include <iostream>
#include <stdexcept>
using namespace std;

class Rectangle {
protected:
    int width = 0;
    int height = 0;
public:
    virtual void SetWidth(int w) { width = w; }
    virtual void SetHeight(int h) { height = h; }
    virtual int GetWidth() const { return width; }
    virtual int GetHeight() const { return height; }

    int GetArea() const {
        return width * height;
    }
    virtual ~Rectangle() {}
};

class Square : public Rectangle {
public:
    void SetWidth(int w) override {
        width = w;
        height = w;
    }
    void SetHeight(int h) override {
        height = h;
        width = h;
    }
};

void TestRectangleArea(Rectangle& rect) {
    rect.SetHeight(5);
    rect.SetWidth(10);
    if (rect.GetArea() != 50) {
        throw runtime_error("Некорректная площадь!");
    }
    cout << "Площадь корректна: " << rect.GetArea() << endl;
}

int main() {
    try {
        cout << "Обычный прямоугольник:" << endl;
        Rectangle rect;
        TestRectangleArea(rect);

        cout << "Квадрат вместо прямоугольника:" << endl;
        Square sq;
        TestRectangleArea(sq); // упадёт: площадь будет 100, не 50
    } catch (const exception& ex) {
        cout << "Ошибка LSP: " << ex.what() << endl;
    }
    return 0;
}
