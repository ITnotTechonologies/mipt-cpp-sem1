// 5.3 LSP — усиление предусловия в наследнике (нарушение)
#include <iostream>
#include <stdexcept>
using namespace std;

class Account {
protected:
    int capital = 0;
public:
    virtual void SetCapital(int money) {
        if (money < 0)
            throw runtime_error("Нельзя положить на счет меньше 0");
        capital = money;
    }
    int GetCapital() const { return capital; }
    virtual ~Account() {}
};

class MicroAccount : public Account {
public:
    void SetCapital(int money) override {
        if (money < 0)
            throw runtime_error("Нельзя положить на счет меньше 0");
        // усилили предусловие — клиент Account этого не ждёт
        if (money > 100)
            throw runtime_error("Нельзя положить на счет больше 100");
        capital = money;
    }
};

void InitializeAccount(Account& account) {
    account.SetCapital(200); // для Account ок, для MicroAccount — нет
    cout << account.GetCapital() << endl;
}

int main() {
    try {
        Account acc;
        InitializeAccount(acc);

        MicroAccount micro;
        InitializeAccount(micro);
    } catch (const exception& ex) {
        cout << "Ошибка LSP: " << ex.what() << endl;
    }
    return 0;
}
