// 5.3 LSP — ослабление постусловия в наследнике (нарушение)
#include <iostream>
#include <stdexcept>
using namespace std;

class Account {
public:
    virtual double GetInterest(double sum, int month, int rate) {
        // предусловие
        if (sum < 0 || month > 12 || month < 1 || rate < 0)
            throw runtime_error("Некорректные данные");

        double result = sum;
        for (int i = 0; i < month; i++)
            result += result * rate / 100.0;

        // постусловие: при sum >= 1000 добавляем бонус
        if (sum >= 1000)
            result += 100;

        return result;
    }
    virtual ~Account() {}
};

class MicroAccount : public Account {
public:
    double GetInterest(double sum, int month, int rate) override {
        if (sum < 0 || month > 12 || month < 1 || rate < 0)
            throw runtime_error("Некорректные данные");

        double result = sum;
        for (int i = 0; i < month; i++)
            result += result * rate / 100.0;

        // бонуса нет — постусловие ослаблено
        return result;
    }
};

void CalculateInterest(Account& account) {
    // 1000 + 1000*10/100 + 100 (бонус) = 1200
    double sum = account.GetInterest(1000, 1, 10);
    if (sum != 1200)
        throw runtime_error("Неожиданная сумма при вычислениях");
    cout << "Сумма: " << sum << endl;
}

int main() {
    try {
        Account acc;
        CalculateInterest(acc);

        MicroAccount micro;
        CalculateInterest(micro); // получит 1100 без бонуса
    } catch (const exception& ex) {
        cout << "Ошибка LSP: " << ex.what() << endl;
    }
    return 0;
}
