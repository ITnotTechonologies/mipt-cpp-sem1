// 5.5 DIP — ХОРОШО: Book зависит от абстракции IPrinter
#include <iostream>
#include <string>
using namespace std;

class IPrinter {
public:
    virtual void Print(const string& text) = 0;
    virtual ~IPrinter() {}
};

class ConsolePrinter : public IPrinter {
public:
    void Print(const string& text) override {
        cout << "Печать на консоли" << endl;
        cout << text << endl;
    }
};

class HtmlPrinter : public IPrinter {
public:
    void Print(const string& text) override {
        cout << "Печать в html" << endl;
        cout << "<html>" << text << "</html>" << endl;
    }
};

class Book {
    IPrinter* printer;
public:
    string text;

    Book(IPrinter* p) : printer(p) {}

    void SetPrinter(IPrinter* p) { printer = p; }

    void Print() {
        printer->Print(text);
    }
};

int main() {
    ConsolePrinter console;
    HtmlPrinter html;

    Book book(&console);
    book.text = "Текст книги";
    book.Print();

    book.SetPrinter(&html);
    book.Print();
    return 0;
}
