// 5.5 DIP — ПЛОХО: Book жёстко зависит от ConsolePrinter
#include <iostream>
#include <string>
using namespace std;

class ConsolePrinter {
public:
    void Print(const string& text) {
        cout << text << endl;
    }
};

class Book {
public:
    string text;
    ConsolePrinter printer;

    void Print() {
        printer.Print(text);
    }
};

int main() {
    Book book;
    book.text = "Текст книги";
    book.Print();
    return 0;
}
