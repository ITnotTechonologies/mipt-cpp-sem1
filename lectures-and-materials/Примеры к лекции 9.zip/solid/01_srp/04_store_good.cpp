// 5.1 SRP — ХОРОШО: каждая обязанность в своём классе
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

class Phone {
public:
    string model;
    int price;
    Phone(string m, int p) : model(m), price(p) {}
};

class IPhoneReader {
public:
    virtual vector<string> GetInputData() = 0;
    virtual ~IPhoneReader() {}
};

class ConsolePhoneReader : public IPhoneReader {
public:
    vector<string> GetInputData() override {
        cout << "Введите модель:" << endl;
        string model;
        getline(cin, model);
        cout << "Введите цену:" << endl;
        string price;
        getline(cin, price);
        return { model, price };
    }
};

class IPhoneBinder {
public:
    virtual Phone CreatePhone(const vector<string>& data) = 0;
    virtual ~IPhoneBinder() {}
};

class GeneralPhoneBinder : public IPhoneBinder {
public:
    Phone CreatePhone(const vector<string>& data) override {
        if (data.size() == 2 && !data[0].empty()) {
            try {
                int price = stoi(data[1]);
                return Phone(data[0], price);
            } catch (...) {}
        }
        throw runtime_error("Ошибка привязчика модели Phone. Некорректные данные");
    }
};

class IPhoneValidator {
public:
    virtual bool IsValid(const Phone& phone) = 0;
    virtual ~IPhoneValidator() {}
};

class GeneralPhoneValidator : public IPhoneValidator {
public:
    bool IsValid(const Phone& phone) override {
        return !phone.model.empty() && phone.price > 0;
    }
};

class IPhoneSaver {
public:
    virtual void Save(const Phone& phone, const string& fileName) = 0;
    virtual ~IPhoneSaver() {}
};

class TextPhoneSaver : public IPhoneSaver {
public:
    void Save(const Phone& phone, const string& fileName) override {
        ofstream writer(fileName, ios::app);
        writer << phone.model << endl;
        writer << phone.price << endl;
    }
};

class MobileStore {
    vector<Phone> phones;
    IPhoneReader* reader;
    IPhoneBinder* binder;
    IPhoneValidator* validator;
    IPhoneSaver* saver;
public:
    MobileStore(IPhoneReader* r, IPhoneBinder* b, IPhoneValidator* v, IPhoneSaver* s)
        : reader(r), binder(b), validator(v), saver(s) {}

    void Process() {
        vector<string> data = reader->GetInputData();
        Phone phone = binder->CreatePhone(data);
        if (validator->IsValid(phone)) {
            phones.push_back(phone);
            saver->Save(phone, "store.txt");
            cout << "Данные успешно обработаны" << endl;
        } else {
            cout << "Некорректные данные" << endl;
        }
    }
};

int main() {
    ConsolePhoneReader reader;
    GeneralPhoneBinder binder;
    GeneralPhoneValidator validator;
    TextPhoneSaver saver;

    MobileStore store(&reader, &binder, &validator, &saver);
    store.Process();
    return 0;
}
