// 5.1 SRP — ПЛОХО: один метод Process делает всё
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

class Phone {
public:
    string model;
    int price;
    Phone(string m, int p) : model(m), price(p) {}
};

class MobileStore {
    vector<Phone> phones;
public:
    void Process() {
        // ввод
        cout << "Введите модель:" << endl;
        string model;
        getline(cin, model);
        cout << "Введите цену:" << endl;
        string priceStr;
        getline(cin, priceStr);

        // валидация
        int price = 0;
        try {
            price = stoi(priceStr);
        } catch (...) {
            throw runtime_error("Некорректно введены данные");
        }
        if (price <= 0 || model.empty()) {
            throw runtime_error("Некорректно введены данные");
        }

        phones.push_back(Phone(model, price));

        // сохранение
        ofstream writer("store.txt", ios::app);
        writer << model << endl;
        writer << price << endl;

        cout << "Данные успешно обработаны" << endl;
    }
};

int main() {
    try {
        MobileStore store;
        store.Process();
    } catch (const exception& ex) {
        cout << ex.what() << endl;
    }
    return 0;
}
