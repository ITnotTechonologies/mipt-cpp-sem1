// 5.1 SRP — ХОРОШО: навигация в Report, печать в Printer
#include <iostream>
#include <string>
using namespace std;

class Report {
public:
    string text;

    void GoToFirstPage() {
        cout << "Переход к первой странице" << endl;
    }
    void GoToLastPage() {
        cout << "Переход к последней странице" << endl;
    }
    void GoToPage(int pageNumber) {
        cout << "Переход к странице " << pageNumber << endl;
    }
};

// обязанность — печать отчета
class Printer {
public:
    void PrintReport(const Report& report) {
        cout << "Печать отчета" << endl;
        cout << report.text << endl;
    }
};

int main() {
    Report report;
    report.text = "Отчет за квартал";
    report.GoToPage(2);

    Printer printer;
    printer.PrintReport(report);
    return 0;
}
