// 5.1 SRP — ПЛОХО: отчёт и печатает, и листает страницы
#include <iostream>
#include <string>
using namespace std;

class Report {
public:
    string text;

    void GoToFirstPage() {
        cout << "Переход к первой странице" << endl;
    }
    void GoToLastPage() {
        cout << "Переход к последней странице" << endl;
    }
    void GoToPage(int pageNumber) {
        cout << "Переход к странице " << pageNumber << endl;
    }

    // вторая обязанность — печать
    void Print() {
        cout << "Печать отчета" << endl;
        cout << text << endl;
    }
};

int main() {
    Report report;
    report.text = "Отчет за квартал";
    report.GoToFirstPage();
    report.Print();
    return 0;
}
