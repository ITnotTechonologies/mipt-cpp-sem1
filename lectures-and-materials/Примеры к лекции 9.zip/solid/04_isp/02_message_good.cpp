// 5.4 ISP — ХОРОШО: интерфейсы разделены по нуждам
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class IMessage {
public:
    virtual void Send() = 0;
    virtual string GetToAddress() const = 0;
    virtual void SetToAddress(const string& a) = 0;
    virtual string GetFromAddress() const = 0;
    virtual void SetFromAddress(const string& a) = 0;
    virtual ~IMessage() {}
};

class IVoiceMessage : public IMessage {
public:
    virtual const vector<unsigned char>& GetVoice() const = 0;
    virtual void SetVoice(const vector<unsigned char>& v) = 0;
};

class ITextMessage : public IMessage {
public:
    virtual string GetText() const = 0;
    virtual void SetText(const string& t) = 0;
};

class IEmailMessage : public ITextMessage {
public:
    virtual string GetSubject() const = 0;
    virtual void SetSubject(const string& s) = 0;
};

class VoiceMessage : public IVoiceMessage {
    string toAddress, fromAddress;
    vector<unsigned char> voice;
public:
    string GetToAddress() const override { return toAddress; }
    void SetToAddress(const string& a) override { toAddress = a; }
    string GetFromAddress() const override { return fromAddress; }
    void SetFromAddress(const string& a) override { fromAddress = a; }
    const vector<unsigned char>& GetVoice() const override { return voice; }
    void SetVoice(const vector<unsigned char>& v) override { voice = v; }

    void Send() override {
        cout << "Передача голосовой почты" << endl;
    }
};

class EmailMessage : public IEmailMessage {
    string text, subject, toAddress, fromAddress;
public:
    string GetText() const override { return text; }
    void SetText(const string& t) override { text = t; }
    string GetSubject() const override { return subject; }
    void SetSubject(const string& s) override { subject = s; }
    string GetToAddress() const override { return toAddress; }
    void SetToAddress(const string& a) override { toAddress = a; }
    string GetFromAddress() const override { return fromAddress; }
    void SetFromAddress(const string& a) override { fromAddress = a; }

    void Send() override {
        cout << "Отправляем по Email сообщение: " << text << endl;
    }
};

class SmsMessage : public ITextMessage {
    string text, toAddress, fromAddress;
public:
    string GetText() const override { return text; }
    void SetText(const string& t) override { text = t; }
    string GetToAddress() const override { return toAddress; }
    void SetToAddress(const string& a) override { toAddress = a; }
    string GetFromAddress() const override { return fromAddress; }
    void SetFromAddress(const string& a) override { fromAddress = a; }

    void Send() override {
        cout << "Отправляем по Sms сообщение: " << text << endl;
    }
};

int main() {
    EmailMessage email;
    email.SetText("Привет");
    email.SetSubject("Тема");
    email.Send();

    SmsMessage sms;
    sms.SetText("Привет");
    sms.Send();

    VoiceMessage voice;
    voice.Send();
    return 0;
}
