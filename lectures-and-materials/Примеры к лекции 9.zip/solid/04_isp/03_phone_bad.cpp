// 5.4 ISP — ПЛОХО: Camera вынуждена реализовывать Call/Video/Web
#include <iostream>
using namespace std;

class IPhone {
public:
    virtual void Call() = 0;
    virtual void TakePhoto() = 0;
    virtual void MakeVideo() = 0;
    virtual void BrowseInternet() = 0;
    virtual ~IPhone() {}
};

class Phone : public IPhone {
public:
    void Call() override { cout << "Звоним" << endl; }
    void TakePhoto() override { cout << "Фотографируем" << endl; }
    void MakeVideo() override { cout << "Снимаем видео" << endl; }
    void BrowseInternet() override { cout << "Серфим в интернете" << endl; }
};

class Camera : public IPhone {
public:
    void Call() override {} // пустой метод — признак нарушения ISP
    void TakePhoto() override { cout << "Фотографируем" << endl; }
    void MakeVideo() override {}
    void BrowseInternet() override {}
};

class Photograph {
public:
    void TakePhoto(IPhone& phone) {
        phone.TakePhoto();
    }
};

int main() {
    Photograph photograph;
    Phone myPhone;
    Camera camera;

    photograph.TakePhoto(myPhone);
    photograph.TakePhoto(camera);
    return 0;
}
