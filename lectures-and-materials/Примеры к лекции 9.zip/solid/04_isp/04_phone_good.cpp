// 5.4 ISP — ХОРОШО: маленькие интерфейсы, Camera реализует только IPhoto
#include <iostream>
using namespace std;

class ICall {
public:
    virtual void Call() = 0;
    virtual ~ICall() {}
};

class IPhoto {
public:
    virtual void TakePhoto() = 0;
    virtual ~IPhoto() {}
};

class IVideo {
public:
    virtual void MakeVideo() = 0;
    virtual ~IVideo() {}
};

class IWeb {
public:
    virtual void BrowseInternet() = 0;
    virtual ~IWeb() {}
};

class Camera : public IPhoto {
public:
    void TakePhoto() override {
        cout << "Фотографируем с помощью фотокамеры" << endl;
    }
};

class Phone : public ICall, public IPhoto, public IVideo, public IWeb {
public:
    void Call() override { cout << "Звоним" << endl; }
    void TakePhoto() override {
        cout << "Фотографируем с помощью смартфона" << endl;
    }
    void MakeVideo() override { cout << "Снимаем видео" << endl; }
    void BrowseInternet() override { cout << "Серфим в интернете" << endl; }
};

class Photograph {
public:
    void TakePhoto(IPhoto& photoMaker) {
        photoMaker.TakePhoto();
    }
};

int main() {
    Photograph photograph;
    Phone phone;
    Camera camera;

    photograph.TakePhoto(phone);
    photograph.TakePhoto(camera);
    return 0;
}
