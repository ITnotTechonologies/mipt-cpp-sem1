// 5.4 ISP — ПЛОХО: «толстый» интерфейс, Sms вынужден реализовывать Subject
#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

class IMessage {
public:
    virtual void Send() = 0;
    virtual string GetText() const = 0;
    virtual void SetText(const string& t) = 0;
    virtual string GetSubject() const = 0;
    virtual void SetSubject(const string& s) = 0;
    virtual string GetToAddress() const = 0;
    virtual void SetToAddress(const string& a) = 0;
    virtual string GetFromAddress() const = 0;
    virtual void SetFromAddress(const string& a) = 0;
    virtual ~IMessage() {}
};

class EmailMessage : public IMessage {
    string text, subject, toAddress, fromAddress;
public:
    string GetText() const override { return text; }
    void SetText(const string& t) override { text = t; }
    string GetSubject() const override { return subject; }
    void SetSubject(const string& s) override { subject = s; }
    string GetToAddress() const override { return toAddress; }
    void SetToAddress(const string& a) override { toAddress = a; }
    string GetFromAddress() const override { return fromAddress; }
    void SetFromAddress(const string& a) override { fromAddress = a; }

    void Send() override {
        cout << "Отправляем Email-сообщение: " << text << endl;
    }
};

class SmsMessage : public IMessage {
    string text, toAddress, fromAddress;
public:
    string GetText() const override { return text; }
    void SetText(const string& t) override { text = t; }
    string GetToAddress() const override { return toAddress; }
    void SetToAddress(const string& a) override { toAddress = a; }
    string GetFromAddress() const override { return fromAddress; }
    void SetFromAddress(const string& a) override { fromAddress = a; }

    // SMS не имеет темы — приходится бросать исключение
    string GetSubject() const override {
        throw runtime_error("NotImplemented");
    }
    void SetSubject(const string&) override {
        throw runtime_error("NotImplemented");
    }

    void Send() override {
        cout << "Отправляем Sms-сообщение: " << text << endl;
    }
};

int main() {
    EmailMessage email;
    email.SetText("Привет");
    email.SetSubject("Тема");
    email.Send();

    SmsMessage sms;
    sms.SetText("Привет");
    sms.Send();
    return 0;
}
