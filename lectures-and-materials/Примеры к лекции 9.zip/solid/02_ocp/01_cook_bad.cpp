// 5.2 OCP — ПЛОХО: чтобы добавить блюдо, надо менять Cook
#include <iostream>
#include <string>
using namespace std;

class Cook {
public:
    string name;
    Cook(string n) : name(n) {}

    void MakeDinner() {
        cout << "Чистим картошку" << endl;
        cout << "Ставим почищенную картошку на огонь" << endl;
        cout << "Сливаем остатки воды, разминаем вареный картофель в пюре" << endl;
        cout << "Посыпаем пюре специями и зеленью" << endl;
        cout << "Картофельное пюре готово" << endl;
    }
};

int main() {
    Cook bob("Bob");
    bob.MakeDinner();
    return 0;
}
