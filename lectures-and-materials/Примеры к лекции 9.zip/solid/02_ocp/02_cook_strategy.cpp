// 5.2 OCP — ХОРОШО (стратегия): новые блюда без изменения Cook
#include <iostream>
#include <string>
using namespace std;

class IMeal {
public:
    virtual void Make() = 0;
    virtual ~IMeal() {}
};

class PotatoMeal : public IMeal {
public:
    void Make() override {
        cout << "Чистим картошку" << endl;
        cout << "Ставим почищенную картошку на огонь" << endl;
        cout << "Сливаем остатки воды, разминаем вареный картофель в пюре" << endl;
        cout << "Посыпаем пюре специями и зеленью" << endl;
        cout << "Картофельное пюре готово" << endl;
    }
};

class SaladMeal : public IMeal {
public:
    void Make() override {
        cout << "Нарезаем помидоры и огурцы" << endl;
        cout << "Посыпаем зеленью, солью и специями" << endl;
        cout << "Поливаем подсолнечным маслом" << endl;
        cout << "Салат готов" << endl;
    }
};

class Cook {
public:
    string name;
    Cook(string n) : name(n) {}

    void MakeDinner(IMeal& meal) {
        meal.Make();
    }
};

int main() {
    Cook bob("Bob");
    PotatoMeal potato;
    SaladMeal salad;

    bob.MakeDinner(potato);
    cout << endl;
    bob.MakeDinner(salad);
    return 0;
}
