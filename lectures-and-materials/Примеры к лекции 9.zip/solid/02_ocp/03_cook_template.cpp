// 5.2 OCP — ХОРОШО (шаблонный метод): общий алгоритм Make()
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class MealBase {
public:
    void Make() {
        Prepare();
        Cook();
        FinalSteps();
    }
    virtual ~MealBase() {}
protected:
    virtual void Prepare() = 0;
    virtual void Cook() = 0;
    virtual void FinalSteps() = 0;
};

class PotatoMeal : public MealBase {
protected:
    void Prepare() override {
        cout << "Чистим и моем картошку" << endl;
    }
    void Cook() override {
        cout << "Ставим почищенную картошку на огонь" << endl;
        cout << "Варим около 30 минут" << endl;
        cout << "Сливаем остатки воды, разминаем вареный картофель в пюре" << endl;
    }
    void FinalSteps() override {
        cout << "Посыпаем пюре специями и зеленью" << endl;
        cout << "Картофельное пюре готово" << endl;
    }
};

class SaladMeal : public MealBase {
protected:
    void Prepare() override {
        cout << "Моем помидоры и огурцы" << endl;
    }
    void Cook() override {
        cout << "Нарезаем помидоры и огурцы" << endl;
        cout << "Посыпаем зеленью, солью и специями" << endl;
    }
    void FinalSteps() override {
        cout << "Поливаем подсолнечным маслом" << endl;
        cout << "Салат готов" << endl;
    }
};

class Cook {
public:
    string name;
    Cook(string n) : name(n) {}

    void MakeDinner(vector<MealBase*>& menu) {
        for (MealBase* meal : menu) {
            meal->Make();
        }
    }
};

int main() {
    PotatoMeal potato;
    SaladMeal salad;
    vector<MealBase*> menu = { &potato, &salad };

    Cook bob("Bob");
    bob.MakeDinner(menu);
    return 0;
}
