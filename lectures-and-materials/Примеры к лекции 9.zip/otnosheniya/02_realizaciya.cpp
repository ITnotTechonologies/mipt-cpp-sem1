// Глава 1.2 — Реализация (Realization)
// Car реализует «интерфейс» IMovable
#include <iostream>
using namespace std;

class IMovable {
public:
    virtual void Move() = 0;
    virtual ~IMovable() {}
};

class Car : public IMovable {
public:
    void Move() override {
        cout << "Машина едет" << endl;
    }
};

int main() {
    Car car;
    car.Move();
    return 0;
}
