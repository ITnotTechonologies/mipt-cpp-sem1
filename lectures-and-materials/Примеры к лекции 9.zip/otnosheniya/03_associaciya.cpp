// Глава 1.2 — Ассоциация (Association)
// Player связан с Team, но они существуют независимо
#include <iostream>
#include <string>
using namespace std;

class Team {
public:
    string name;
};

class Player {
public:
    string name;
    Team* team; // связь-ассоциация
};

int main() {
    Team t;
    t.name = "Dream Team";

    Player p;
    p.name = "Bob";
    p.team = &t;

    cout << p.name << " играет в " << p.team->name << endl;
    return 0;
}
