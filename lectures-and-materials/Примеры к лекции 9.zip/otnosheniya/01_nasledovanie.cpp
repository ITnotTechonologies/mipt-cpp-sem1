// Глава 1.2 — Наследование (Inheritance)
// Manager является User
#include <iostream>
#include <string>
using namespace std;

class User {
public:
    int id;
    string name;
};

class Manager : public User {
public:
    string company;
};

int main() {
    Manager m;
    m.id = 1;
    m.name = "Tom";
    m.company = "Microsoft";

    cout << m.id << " " << m.name << " " << m.company << endl;
    return 0;
}
