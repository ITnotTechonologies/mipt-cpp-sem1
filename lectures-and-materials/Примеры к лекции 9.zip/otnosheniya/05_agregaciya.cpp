// Глава 1.2 — Агрегация (Aggregation)
// Двигатель передаётся снаружи и может жить отдельно от Car
#include <iostream>
using namespace std;

class Engine {
public:
    virtual void Start() = 0;
    virtual ~Engine() {}
};

class PetrolEngine : public Engine {
public:
    void Start() override {
        cout << "Бензиновый мотор запущен" << endl;
    }
};

class Car {
    Engine* engine; // внешняя зависимость
public:
    Car(Engine* eng) : engine(eng) {}

    void Drive() {
        engine->Start();
        cout << "Машина едет" << endl;
    }
};

int main() {
    PetrolEngine eng;
    Car car(&eng);
    car.Drive();
    return 0;
}
