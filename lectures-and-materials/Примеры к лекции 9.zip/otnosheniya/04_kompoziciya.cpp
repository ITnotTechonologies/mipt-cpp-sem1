// Глава 1.2 — Композиция (Composition)
// Двигатель создаётся внутри Car и без Car не существует
#include <iostream>
using namespace std;

class ElectricEngine {
public:
    void Start() {
        cout << "Электромотор запущен" << endl;
    }
};

class Car {
    ElectricEngine engine; // часть целого
public:
    void Drive() {
        engine.Start();
        cout << "Машина едет" << endl;
    }
};

int main() {
    Car car;
    car.Drive();
    return 0;
}
