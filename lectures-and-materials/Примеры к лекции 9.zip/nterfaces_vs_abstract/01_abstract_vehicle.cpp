// Глава 1.3 — Абстрактный класс Vehicle
#include <iostream>
using namespace std;

class Vehicle {
public:
    virtual void Move() = 0;
    virtual ~Vehicle() {}
};

class Car : public Vehicle {
public:
    void Move() override {
        cout << "Машина едет" << endl;
    }
};

class Bus : public Vehicle {
public:
    void Move() override {
        cout << "Автобус едет" << endl;
    }
};

class Tram : public Vehicle {
public:
    void Move() override {
        cout << "Трамвай едет" << endl;
    }
};

int main() {
    Car car;
    Bus bus;
    Tram tram;

    car.Move();
    bus.Move();
    tram.Move();
    return 0;
}
