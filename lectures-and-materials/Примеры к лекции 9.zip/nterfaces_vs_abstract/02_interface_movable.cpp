// Глава 1.3 — Интерфейс IMovable + абстрактный Vehicle
// Не только транспорт может двигаться
#include <iostream>
using namespace std;

class IMovable {
public:
    virtual void Move() = 0;
    virtual ~IMovable() {}
};

class Vehicle : public IMovable {
public:
    virtual void Move() = 0;
};

class Car : public Vehicle {
public:
    void Move() override {
        cout << "Машина едет" << endl;
    }
};

class Bus : public Vehicle {
public:
    void Move() override {
        cout << "Автобус едет" << endl;
    }
};

class Horse : public IMovable {
public:
    void Move() override {
        cout << "Лошадь скачет" << endl;
    }
};

class Aircraft : public IMovable {
public:
    void Move() override {
        cout << "Самолет летит" << endl;
    }
};

void Go(IMovable& m) {
    m.Move();
}

int main() {
    Car car;
    Horse horse;
    Aircraft plane;

    Go(car);
    Go(horse);
    Go(plane);
    return 0;
}
